package com.mms.paises.server.services.Impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mms.paises.cliente.model.Country;
import com.mms.paises.cliente.services.ClienteService;
import com.mms.paises.server.model.Pais;
import com.mms.paises.server.services.PaisesService;

@Service
public class PaisesServiceImpl implements PaisesService {
	
	// inyectaremos un servicio de la "parte B" 
	
	@Autowired
	private ClienteService clienteService;
	
	@Override
	public List<Pais> getAll() {
				
		List<Country> countries = clienteService.getAll();
		
		List<Pais> paises = new ArrayList<>();
		
		for(Country country: countries) {
			Pais pais = new Pais();
			pais.setNombre(country.getName());
			pais.setCapital(country.getCapital());
			pais.setPoblacion(country.getPopulation());
			paises.add(pais);
		}
		
		return paises;
	
	}

	@Override
	public Pais getByCountryName(String name) {
		
		Country country = clienteService.getByName(name);
		
		Pais pais = new Pais();
		pais.setNombre(country.getName());
		pais.setCapital(country.getCapital());
		pais.setPoblacion(country.getPopulation());
		
		return pais;
	}


}
