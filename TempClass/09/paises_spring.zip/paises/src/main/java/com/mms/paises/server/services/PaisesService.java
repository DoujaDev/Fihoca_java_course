package com.mms.paises.server.services;
import java.util.List;

import com.mms.paises.server.model.Pais;

public interface PaisesService {
	
	public List<Pais> getAll();

	public Pais getByCountryName(String name);
	
}
