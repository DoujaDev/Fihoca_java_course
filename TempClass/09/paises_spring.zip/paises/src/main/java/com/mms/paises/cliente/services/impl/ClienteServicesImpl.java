package com.mms.paises.cliente.services.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mms.paises.cliente.model.Country;
import com.mms.paises.cliente.services.ClienteService;
import com.mms.paises.server.model.Pais;

@Service
public class ClienteServicesImpl implements ClienteService{
	
	private static RestTemplate restTemplate = new RestTemplate();
	private static HttpHeaders headers = new HttpHeaders();
	private static String url = "https://restcountries.eu/rest/v2/";
	
	static {
		
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		
	}
	
	@Override
	public Country getByName(String name) {
		// TODO Auto-generated method stub
		
		// 1.- Vamos a crear countries dummy "de mentira" para ver si en el otro lado funciona
		
//		Country country = new Country();
//		country.setName(name);
//		country.setCapital("capital A");
//		country.setPopulation(100000);
		
		
		
		// 2.- Cundo comprobemos que "en el otro lado" funciona, vamos a implementar el rest-tempalte
		
		
		return country;
	}

	@Override
	public List<Pais> getAll() {
		// TODO Auto-generated method stub
		
		List<Pais> countries = new ArrayList<Pais>();
		
		String resourceURL = url + "all";
		HttpEntity<String> entity = new HttpEntity<String> (headers);
		ResponseEntity<Country[]> response = restTemplate.exchange(resourceURL, HttpMethod.GET, entity, Country[].class);
		
		if(response.getStatusCode()== HttpStatus.OK) {
			for(Country restPais : response.getBody()) {
				Pais respuesta = new Pais();
				respuesta.convert(restPais);
				countries.add(respuesta);
			}
		} else {
			
			System.out.println("error");
		}
		
//		Country country1 = new Country();
//		country1.setName("Españistán");
//		country1.setCapital("capital Mandril");
//		country1.setPopulation(150000);
//		
//		Country country2 = new Country();
//		country2.setName("Afghanistán");
//		country2.setCapital("Kabul");
//		country2.setPopulation(100000);
//		
//		countries.add(country1);
//		countries.add(country2);
		
		return countries;
	}

}
