package com.mms.paises.cliente.model;

// modelo adaptado a lo que entrega restcountries
// los atributos ignorados "no juegan"

public class Country {
	
	private String name;
	private String capital;
	private int population;
	
	public Country() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public int getPopulation() {
		return population;
	}

	public void setPopulation(int population) {
		this.population = population;
	}

	@Override
	public String toString() {
		return "Country [name=" + name + ", capital=" + capital + ", population=" + population + "]";
	}
	
	
}
