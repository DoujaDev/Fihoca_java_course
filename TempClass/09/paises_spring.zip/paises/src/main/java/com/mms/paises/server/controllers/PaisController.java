package com.mms.paises.server.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mms.paises.server.model.Pais;
import com.mms.paises.server.services.PaisesService;

@RestController
public class PaisController {
	
	@Autowired
	private PaisesService paisesService;
	
	// DEVUELVE TODOS LOS PAISES
	@GetMapping("/paises")
	public List<Pais> paises() {
		
		return paisesService.getAll(); 
	}
	
	// DEVUELVE UN PAIS A PARTIT DE SU NUMBRE
	@GetMapping("/paises/{nombre}")
	public Pais nombre(@PathVariable ("nombre") String nombre) {
		
		return paisesService.getByCountryName(nombre);
	}
	

}
