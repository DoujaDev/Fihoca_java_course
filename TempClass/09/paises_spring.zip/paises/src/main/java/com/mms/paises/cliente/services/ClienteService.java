package com.mms.paises.cliente.services;

import java.util.List;

import com.mms.paises.cliente.model.Country;
import com.mms.paises.server.model.Pais;

public interface ClienteService {

	public Country getByName(String name);
	public List<Pais> getAll();
	
}
