package com.mms.paises;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaisesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaisesApplication.class, args);
	}

}
