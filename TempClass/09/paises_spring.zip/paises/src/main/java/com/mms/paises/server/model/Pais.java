package com.mms.paises.server.model;

import com.mms.paises.cliente.model.Country;

public class Pais {
	
	private String nombre;
	private String capital;
	private int numeroFronteras;
	private int numeroIdiomas;
	private int poblacion;
	
	public Pais() {
		
	}
	
	public Pais(String nombre, String capital, int numeroFronteras, int numeroIdiomas, int poblacion) {
		this.nombre = nombre;
		this.capital = capital;
		this.numeroFronteras = numeroFronteras;
		this.numeroIdiomas = numeroIdiomas;
		this.poblacion = poblacion;
	}
	
	// Meoodo convert añadido
	public Pais convert(Country country) {
		
		Pais pais = new Pais();
		pais.setNombre(country.getName());
		pais.setCapital(country.getCapital());
		pais.setPoblacion(country.getPopulation());
		
		return pais;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public int getNumeroFronteras() {
		return numeroFronteras;
	}

	public void setNumeroFronteras(int numeroFronteras) {
		this.numeroFronteras = numeroFronteras;
	}

	public int getNumeroIdiomas() {
		return numeroIdiomas;
	}

	public void setNumeroIdiomas(int numeroIdiomas) {
		this.numeroIdiomas = numeroIdiomas;
	}

	public int getPoblacion() {
		return poblacion;
	}

	public void setPoblacion(int poblacion) {
		this.poblacion = poblacion;
	}

	@Override
	public String toString() {
		return "Pais [nombre=" + nombre + ", capital=" + capital + ", numeroFronteras=" + numeroFronteras
				+ ", numeroIdiomas=" + numeroIdiomas + ", poblacion=" + poblacion + "]";
	}
	
}
